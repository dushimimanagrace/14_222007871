-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 14, 2024 at 11:12 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `fname` varchar(60) NOT NULL,
  `lname` varchar(60) NOT NULL,
  `loc` varchar(60) NOT NULL,
  `dis` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `phone` varchar(60) NOT NULL,
  `gender` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`fname`, `lname`, `loc`, `dis`, `email`, `phone`, `gender`) VALUES
('grace', 'dushimimana', 'kigali', 'kicukiro', 'grace', '0790150556', 'female'),
('grace', 'dushimimana', 'kigali', 'kicukiro', 'grace', '079015556', 'female'),
('', '', '', '', '', '', 'male'),
('', '', '', '', '', '', 'male'),
('', '', '', '', '', '', 'male'),
('grace', 'dushimimana', 'kigali', 'kicukiro', 'grace', '758949867', 'female'),
('grace', 'dushimimana', 'kigali', 'kicukiro', 'grace', '079387634', 'female'),
('[value-1]', '[value-2]', '[value-3]', '[value-4]', '[value-5]', '[value-6]', '[value-7]'),
('Dushiminmana', 'Grace', 'kigali', 'kicukiro', 'garce@gmail.com', '0790150556', 'female'),
('Dushiminmana', 'Grace', 'kigali', 'kicukiro', 'garce@gmail.com', '0790150556', 'female'),
('Dushimimana', 'Grace', 'kigali', 'kicukiro', 'grace@gmail.com', '0790150556', 'female'),
('Dushimimana', 'Grace', 'kigali', 'kicukiro', 'grace@gmail.com', '0790150556', 'female'),
('eric', 'erimu', 'kgl', 'gikondo', 'df@gmail.com', '0786903456', 'male'),
('eric', 'erimu', 'kgl', 'gikondo', 'fgh@gmail.com', '0786903456', 'male'),
('dushime', 'grc', 'kgl', 'gknd', 'dfgh@gmail.com', '079234567', 'female'),
('dushime', 'grc', 'kgl', 'gknd', 'dfgh@gmail.com', '079234567', 'female'),
('sdf', 'sdfgh', 'kjhgf', 'kjhg', 'lkjhg@gmail.com', '09876543', 'others'),
('sdfg', 'jhg', 'rtyu', 'wer', 'jhg@gmail.com', '9876543', 'male'),
('sdfg', 'jhg', 'rtyu', 'wer', 'jhg@gmail.com', '9876543', 'male'),
('sdfg', 'jhg', 'rtyu', 'wer', 'jhg@gmail.com', '9876543', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE `user_registration` (
  `User_Name` varchar(60) NOT NULL,
  `Phone_Number` int(20) NOT NULL,
  `Email` varchar(60) NOT NULL,
  `Gender` varchar(30) NOT NULL,
  `Password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`User_Name`, `Phone_Number`, `Email`, `Gender`, `Password`) VALUES
('Grace', 790150556, 'dushimimanagrace44@gtmail.com', 'Female', 'nyamirama'),
('s', 7, 's', 'Male', 's'),
('f', 12, 'f', 'Male', 'f');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
